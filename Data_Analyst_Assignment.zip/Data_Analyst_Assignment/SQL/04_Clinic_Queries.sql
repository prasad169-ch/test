-- Q1. revenue from each sales channel for 2021

select sales_channel, sum(amount) as total_revenue
from clinic_sales
where extract(year from datetime) = 2021
group by sales_channel
order by total_revenue desc;


-- Q2. top 10 most valuable customers in 2021

select cs.uid, c.name, sum(cs.amount) as total_spend
from clinic_sales cs
join customer c on c.uid = cs.uid
where extract(year from cs.datetime) = 2021
group by cs.uid, c.name
order by total_spend desc
limit 10;


-- Q3. month wise revenue, expense, profit and status for 2021

with rev as (
    select extract(month from datetime) as mnth, sum(amount) as revenue
    from clinic_sales
    where extract(year from datetime) = 2021
    group by extract(month from datetime)
),
exp as (
    select extract(month from datetime) as mnth, sum(amount) as expense
    from expenses
    where extract(year from datetime) = 2021
    group by extract(month from datetime)
)
select
    r.mnth as month,
    r.revenue,
    coalesce(e.expense, 0) as expense,
    r.revenue - coalesce(e.expense, 0) as profit,
    case when r.revenue - coalesce(e.expense, 0) >= 0 then 'profitable' else 'not-profitable' end as status
from rev r
left join exp e on e.mnth = r.mnth
order by r.mnth;


-- Q4. most profitable clinic per city for november 2021

with rev as (
    select cid, sum(amount) as revenue
    from clinic_sales
    where extract(year from datetime) = 2021 and extract(month from datetime) = 11
    group by cid
),
exp as (
    select cid, sum(amount) as expense
    from expenses
    where extract(year from datetime) = 2021 and extract(month from datetime) = 11
    group by cid
),
profit as (
    select cl.cid, cl.clinic_name, cl.city,
        coalesce(r.revenue, 0) - coalesce(e.expense, 0) as profit
    from clinics cl
    left join rev r on r.cid = cl.cid
    left join exp e on e.cid = cl.cid
),
rnk as (
    select *, rank() over (partition by city order by profit desc) as rk
    from profit
)
select city, cid, clinic_name, profit
from rnk
where rk = 1;


-- Q5. second least profitable clinic per state for november 2021

with rev as (
    select cid, sum(amount) as revenue
    from clinic_sales
    where extract(year from datetime) = 2021 and extract(month from datetime) = 11
    group by cid
),
exp as (
    select cid, sum(amount) as expense
    from expenses
    where extract(year from datetime) = 2021 and extract(month from datetime) = 11
    group by cid
),
profit as (
    select cl.cid, cl.clinic_name, cl.city, cl.state,
        coalesce(r.revenue, 0) - coalesce(e.expense, 0) as profit
    from clinics cl
    left join rev r on r.cid = cl.cid
    left join exp e on e.cid = cl.cid
),
rnk as (
    select *, dense_rank() over (partition by state order by profit asc) as dr
    from profit
)
select state, cid, clinic_name, city, profit
from rnk
where dr = 2;

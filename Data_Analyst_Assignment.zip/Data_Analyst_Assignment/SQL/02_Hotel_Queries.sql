-- Q1. user_id and last booked room for every user

select u.user_id, u.name, b.room_no
from users u
join bookings b on u.user_id = b.user_id
where b.booking_date = (
    select max(b2.booking_date) from bookings b2 where b2.user_id = u.user_id
);


-- Q2. booking_id and total bill amount for bookings in november 2021

select b.booking_id, sum(bc.item_quantity * i.item_rate) as total_amount
from bookings b
join booking_commercials bc on bc.booking_id = b.booking_id
join items i on i.item_id = bc.item_id
where extract(year from b.booking_date) = 2021
and extract(month from b.booking_date) = 11
group by b.booking_id;


-- Q3. bill_id and bill amount for bills in october 2021 where amount > 1000

select bc.bill_id, sum(bc.item_quantity * i.item_rate) as bill_amount
from booking_commercials bc
join items i on i.item_id = bc.item_id
where extract(year from bc.bill_date) = 2021
and extract(month from bc.bill_date) = 10
group by bc.bill_id
having sum(bc.item_quantity * i.item_rate) > 1000;


-- Q4. most ordered and least ordered item each month in 2021

with monthly_totals as (
    select
        extract(month from bc.bill_date) as month,
        i.item_name,
        sum(bc.item_quantity) as total_qty
    from booking_commercials bc
    join items i on i.item_id = bc.item_id
    where extract(year from bc.bill_date) = 2021
    group by extract(month from bc.bill_date), i.item_name
),
ranked as (
    select *,
        rank() over (partition by month order by total_qty desc) as rk_most,
        rank() over (partition by month order by total_qty asc) as rk_least
    from monthly_totals
)
select
    month,
    max(case when rk_most = 1 then item_name end) as most_ordered,
    max(case when rk_least = 1 then item_name end) as least_ordered
from ranked
group by month
order by month;


-- Q5. customers with second highest bill value each month in 2021

with user_monthly as (
    select
        extract(month from bc.bill_date) as month,
        b.user_id,
        u.name,
        sum(bc.item_quantity * i.item_rate) as total_bill
    from booking_commercials bc
    join bookings b on b.booking_id = bc.booking_id
    join users u on u.user_id = b.user_id
    join items i on i.item_id = bc.item_id
    where extract(year from bc.bill_date) = 2021
    group by extract(month from bc.bill_date), b.user_id, u.name
),
ranked as (
    select *,
        dense_rank() over (partition by month order by total_bill desc) as dr
    from user_monthly
)
select month, user_id, name, total_bill
from ranked
where dr = 2
order by month;

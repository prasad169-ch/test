create table clinics (
    cid varchar(50) primary key,
    clinic_name varchar(100),
    city varchar(100),
    state varchar(100),
    country varchar(100)
);

create table customer (
    uid varchar(50) primary key,
    name varchar(100),
    mobile varchar(20)
);

create table clinic_sales (
    oid varchar(50) primary key,
    uid varchar(50) references customer(uid),
    cid varchar(50) references clinics(cid),
    amount numeric(12,2),
    datetime timestamp,
    sales_channel varchar(50)
);

create table expenses (
    eid varchar(50) primary key,
    cid varchar(50) references clinics(cid),
    description varchar(200),
    amount numeric(12,2),
    datetime timestamp
);


insert into clinics values
('cnc-001', 'HealthFirst Clinic', 'Mumbai', 'Maharashtra', 'India'),
('cnc-002', 'WellCare Centre', 'Mumbai', 'Maharashtra', 'India'),
('cnc-003', 'CityMed Clinic', 'Bangalore', 'Karnataka', 'India'),
('cnc-004', 'Greenleaf Health', 'Bangalore', 'Karnataka', 'India'),
('cnc-005', 'PrimeCure Hospital', 'Delhi', 'Delhi', 'India');

insert into customer values
('cust-001', 'Ravi Verma', '9811001100'),
('cust-002', 'Meera Nair', '9822002200'),
('cust-003', 'Anil Kumar', '9833003300'),
('cust-004', 'Pooja Singh', '9844004400'),
('cust-005', 'Deepak Joshi', '9855005500'),
('cust-006', 'Neha Gupta', '9866006600'),
('cust-007', 'Suresh Pillai', '9877007700'),
('cust-008', 'Ananya Roy', '9888008800'),
('cust-009', 'Kiran Rao', '9899009900'),
('cust-010', 'Tanya Mishra', '9800001010');

insert into clinic_sales values
('ord-001', 'cust-001', 'cnc-001', 24999, '2021-01-05 09:00:00', 'online'),
('ord-002', 'cust-002', 'cnc-001', 14999, '2021-01-12 10:30:00', 'walk-in'),
('ord-003', 'cust-003', 'cnc-002', 8500,  '2021-01-18 11:00:00', 'online'),
('ord-004', 'cust-004', 'cnc-003', 32000, '2021-01-22 14:00:00', 'referral'),
('ord-005', 'cust-005', 'cnc-004', 11000, '2021-01-28 16:00:00', 'walk-in'),
('ord-006', 'cust-006', 'cnc-001', 19500, '2021-02-03 09:30:00', 'online'),
('ord-007', 'cust-001', 'cnc-002', 27000, '2021-02-14 11:00:00', 'referral'),
('ord-008', 'cust-007', 'cnc-003', 8000,  '2021-02-19 13:00:00', 'walk-in'),
('ord-009', 'cust-008', 'cnc-005', 45000, '2021-02-23 15:30:00', 'online'),
('ord-010', 'cust-009', 'cnc-001', 13000, '2021-03-07 10:00:00', 'walk-in'),
('ord-011', 'cust-010', 'cnc-004', 21000, '2021-03-14 11:30:00', 'online'),
('ord-012', 'cust-002', 'cnc-005', 39000, '2021-03-21 14:00:00', 'referral'),
('ord-013', 'cust-003', 'cnc-001', 17500, '2021-04-05 09:00:00', 'walk-in'),
('ord-014', 'cust-004', 'cnc-002', 22000, '2021-04-13 10:30:00', 'online'),
('ord-015', 'cust-005', 'cnc-003', 30000, '2021-04-20 12:00:00', 'referral'),
('ord-016', 'cust-006', 'cnc-004', 15000, '2021-05-04 09:30:00', 'online'),
('ord-017', 'cust-007', 'cnc-005', 52000, '2021-05-11 11:00:00', 'walk-in'),
('ord-018', 'cust-008', 'cnc-001', 9800,  '2021-05-18 13:30:00', 'online'),
('ord-019', 'cust-009', 'cnc-002', 28000, '2021-06-03 10:00:00', 'referral'),
('ord-020', 'cust-010', 'cnc-003', 11500, '2021-06-17 12:00:00', 'walk-in'),
('ord-021', 'cust-001', 'cnc-004', 36000, '2021-06-25 15:00:00', 'online'),
('ord-022', 'cust-002', 'cnc-001', 25000, '2021-07-06 09:00:00', 'walk-in'),
('ord-023', 'cust-003', 'cnc-005', 48000, '2021-07-14 11:30:00', 'online'),
('ord-024', 'cust-004', 'cnc-002', 18000, '2021-07-22 14:00:00', 'referral'),
('ord-025', 'cust-005', 'cnc-003', 34000, '2021-08-02 10:00:00', 'online'),
('ord-026', 'cust-006', 'cnc-004', 7500,  '2021-08-10 12:30:00', 'walk-in'),
('ord-027', 'cust-007', 'cnc-001', 29000, '2021-08-19 15:00:00', 'online'),
('ord-028', 'cust-008', 'cnc-002', 16000, '2021-09-08 09:00:00', 'walk-in'),
('ord-029', 'cust-009', 'cnc-005', 41000, '2021-09-16 11:00:00', 'referral'),
('ord-030', 'cust-010', 'cnc-003', 12000, '2021-09-24 13:30:00', 'online'),
('ord-031', 'cust-001', 'cnc-004', 23000, '2021-10-04 09:30:00', 'online'),
('ord-032', 'cust-002', 'cnc-001', 31000, '2021-10-12 11:00:00', 'walk-in'),
('ord-033', 'cust-003', 'cnc-005', 55000, '2021-10-20 14:30:00', 'referral'),
('ord-034', 'cust-004', 'cnc-002', 19000, '2021-11-03 10:00:00', 'walk-in'),
('ord-035', 'cust-005', 'cnc-003', 27000, '2021-11-11 12:00:00', 'online'),
('ord-036', 'cust-006', 'cnc-004', 43000, '2021-11-22 15:00:00', 'referral'),
('ord-037', 'cust-007', 'cnc-001', 38000, '2021-12-07 09:00:00', 'online'),
('ord-038', 'cust-008', 'cnc-005', 62000, '2021-12-15 11:30:00', 'walk-in'),
('ord-039', 'cust-009', 'cnc-002', 21000, '2021-12-23 14:00:00', 'referral'),
('ord-040', 'cust-010', 'cnc-003', 14000, '2021-12-30 16:00:00', 'online');

insert into expenses values
('exp-001', 'cnc-001', 'Staff salaries', 85000, '2021-01-31 18:00:00'),
('exp-002', 'cnc-001', 'Medical supplies', 8000, '2021-01-15 10:00:00'),
('exp-003', 'cnc-002', 'Utility bills', 6000, '2021-01-31 17:00:00'),
('exp-004', 'cnc-003', 'Rent', 40000, '2021-01-01 09:00:00'),
('exp-005', 'cnc-004', 'Equipment maintenance', 5000, '2021-01-20 11:00:00'),
('exp-006', 'cnc-001', 'Staff salaries', 85000, '2021-02-28 18:00:00'),
('exp-007', 'cnc-002', 'Medical supplies', 9500, '2021-02-15 10:00:00'),
('exp-008', 'cnc-003', 'Utility bills', 6200, '2021-02-28 17:00:00'),
('exp-009', 'cnc-005', 'Rent', 70000, '2021-02-01 09:00:00'),
('exp-010', 'cnc-001', 'Staff salaries', 87000, '2021-03-31 18:00:00'),
('exp-011', 'cnc-004', 'Medical supplies', 7000, '2021-03-15 10:00:00'),
('exp-012', 'cnc-005', 'Equipment maintenance', 8000, '2021-03-20 11:00:00'),
('exp-013', 'cnc-001', 'Staff salaries', 85000, '2021-04-30 18:00:00'),
('exp-014', 'cnc-002', 'Utility bills', 6500, '2021-04-30 17:00:00'),
('exp-015', 'cnc-003', 'Rent', 40000, '2021-04-01 09:00:00'),
('exp-016', 'cnc-004', 'Staff salaries', 60000, '2021-05-31 18:00:00'),
('exp-017', 'cnc-005', 'Medical supplies', 9000, '2021-05-15 10:00:00'),
('exp-018', 'cnc-001', 'Equipment maintenance', 3500, '2021-05-20 11:00:00'),
('exp-019', 'cnc-002', 'Staff salaries', 55000, '2021-06-30 18:00:00'),
('exp-020', 'cnc-003', 'Utility bills', 6800, '2021-06-30 17:00:00'),
('exp-021', 'cnc-001', 'Staff salaries', 85000, '2021-07-31 18:00:00'),
('exp-022', 'cnc-005', 'Rent', 70000, '2021-07-01 09:00:00'),
('exp-023', 'cnc-003', 'Staff salaries', 65000, '2021-08-31 18:00:00'),
('exp-024', 'cnc-004', 'Medical supplies', 8500, '2021-08-15 10:00:00'),
('exp-025', 'cnc-002', 'Utility bills', 7000, '2021-09-30 17:00:00'),
('exp-026', 'cnc-005', 'Equipment maintenance', 12000, '2021-09-20 11:00:00'),
('exp-027', 'cnc-001', 'Staff salaries', 85000, '2021-10-31 18:00:00'),
('exp-028', 'cnc-004', 'Utility bills', 6000, '2021-10-31 17:00:00'),
('exp-029', 'cnc-002', 'Staff salaries', 55000, '2021-11-30 18:00:00'),
('exp-030', 'cnc-003', 'Rent', 40000, '2021-11-01 09:00:00'),
('exp-031', 'cnc-001', 'Staff salaries', 88000, '2021-12-31 18:00:00'),
('exp-032', 'cnc-005', 'Medical supplies', 11000, '2021-12-15 10:00:00');

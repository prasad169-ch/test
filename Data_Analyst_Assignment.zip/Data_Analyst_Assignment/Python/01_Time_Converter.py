def convert_minutes(mins):
    hrs = mins // 60
    remaining = mins % 60
    if hrs == 0:
        return str(remaining) + " minutes"
    elif hrs == 1:
        return "1hr " + str(remaining) + "minutes"
    else:
        return str(hrs) + " hrs " + str(remaining) + " minutes"


print(convert_minutes(130))
print(convert_minutes(110))
print(convert_minutes(60))
print(convert_minutes(45))
print(convert_minutes(90))
print(convert_minutes(200))

def remove_duplicates(s):
    result = ""
    for char in s:
        if char not in result:
            result += char
    return result


s = "programming"
print(remove_duplicates(s))

s = "aabbccdd"
print(remove_duplicates(s))

s = "hello world"
print(remove_duplicates(s))

s = "mississippi"
print(remove_duplicates(s))

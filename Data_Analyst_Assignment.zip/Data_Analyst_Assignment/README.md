## PlatinumRx Data Analyst Assignment

### SQL

For part A (Hotel), I created 4 tables - users, bookings, items and booking_commercials. Inserted some sample data and wrote the queries.

- Q1 - used a correlated subquery to get the latest booking date for each user and then got the room from that row
- Q2 - joined all 3 tables and used sum(qty * rate) grouped by booking_id, filtered for november 2021
- Q3 - same as above but filtered for october and used having to get bills above 1000
- Q4 - used CTEs and rank() window function to rank items by quantity per month, then picked rank 1 for most and least
- Q5 - used dense_rank() partitioned by month ordered by total bill descending, picked rank 2

For part B (Clinic), tables are clinics, customer, clinic_sales and expenses.

- Q1 - simple group by on sales_channel with sum
- Q2 - joined clinic_sales and customer, grouped by uid, ordered by total spend desc, limit 10
- Q3 - two CTEs for revenue and expenses, left joined them on month, calculated profit and added a case statement for status
- Q4 - profit CTE + rank() partitioned by city, filtered rank = 1
- Q5 - same but dense_rank() partitioned by state ordered asc, filtered rank = 2

### Spreadsheets

The workbook has 3 sheets - ticket, feedbacks and Outlet_Ticket_Analysis.

For Q1, I used INDEX MATCH in the feedbacks sheet to get ticket_created_at based on cms_id. I didn't use VLOOKUP here because created_at is to the left of cms_id in the ticket sheet, so VLOOKUP wouldn't work directly.

Formula used:
```
=IFERROR(INDEX(ticket!$B:$B,MATCH(A2,ticket!$E:$E,0)),"Not Found")
```

For Q2a (same day), I used SUMPRODUCT comparing INT() of created_at and closed_at per outlet:
```
=SUMPRODUCT((ticket!$D$2:$D$100=A5)*(INT(ticket!$B$2:$B$100)=INT(ticket!$C$2:$C$100)))
```

For Q2b (same hour same day), added HOUR() check as well:
```
=SUMPRODUCT((ticket!$D$2:$D$100=A5)*(INT(ticket!$B$2:$B$100)=INT(ticket!$C$2:$C$100))*(HOUR(ticket!$B$2:$B$100)=HOUR(ticket!$C$2:$C$100)))
```

### Python

Q1 - divide minutes by 60 to get hours, remainder gives the leftover minutes. Printed in readable format.

Q2 - loop through string, if character is not already in result string add it. This preserves the order and removes duplicates.

### How to run

SQL: Run the schema setup file first then the queries file in pgAdmin or any postgres client.

Python: just run the scripts directly with python3.

Spreadsheet: open the xlsx in Excel, all formulas should work as is.
